<?php
/*
Template Name: Home Page Template
*/
?>

<?php get_header(); ?>

<?php get_home_sections(); ?>

<?php get_footer(); ?>